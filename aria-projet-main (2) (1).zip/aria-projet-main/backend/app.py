from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np
import os
from defense import verify_model_integrity, register_model_hash

app = Flask(__name__)
CORS(app)

MODEL_PATH = "models/aria_model.pkl"

def load_model():
    with open(MODEL_PATH, "rb") as f:
        return pickle.load(f)

@app.route("/predict", methods=["POST"])
def predict():
    # ── Vérification de l'intégrité avant chaque prédiction ──────────────
    intact, current_hash = verify_model_integrity(MODEL_PATH)
    if not intact:
        return jsonify({
            "error": "INTÉGRITÉ COMPROMISE",
            "compromised": True,
            "message": "Le modèle a été modifié. Prédiction bloquée par le système de défense.",
            "hash": current_hash
        }), 403
    # ─────────────────────────────────────────────────────────────────────

    data = request.json
    features = [
        data["age"], data["sex"], data["cp"], data["trestbps"],
        data["chol"], data["fbs"], data["restecg"], data["thalach"],
        data["exang"], data["oldpeak"], data["slope"], data["ca"], data["thal"]
    ]
    model = load_model()
    prediction = model.predict([features])[0]
    proba = model.predict_proba([features])[0]
    confidence = round(float(max(proba)) * 100, 1)

    return jsonify({
        "diagnostic": int(prediction),
        "label": "RISQUE CARDIAQUE DÉTECTÉ" if prediction == 1 else "AUCUN RISQUE DÉTECTÉ",
        "confidence": confidence,
        "compromised": False
    })

@app.route("/status", methods=["GET"])
def status():
    intact, current_hash = verify_model_integrity(MODEL_PATH)
    return jsonify({
        "status": "ok",
        "model": MODEL_PATH,
        "integrity": "verified" if intact else "COMPROMISED",
        "compromised": not intact,
        "hash": current_hash
    })

if __name__ == "__main__":
    # À la première exécution : enregistre le hash si pas encore fait
    hash_ref = "models/aria_model.sha256"
    if not os.path.exists(hash_ref):
        print("🔐 Première exécution — enregistrement du hash de référence...")
        register_model_hash(MODEL_PATH)
    app.run(debug=True, port=5000)
