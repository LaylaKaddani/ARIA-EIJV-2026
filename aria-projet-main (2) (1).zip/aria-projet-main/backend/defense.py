import hashlib
import os
import json

MODEL_PATH    = "models/aria_model.pkl"
HASH_REF_PATH = "models/aria_model.sha256"

# ── 1. Calcul de l'empreinte SHA-256 ──────────────────────────────────────
def compute_hash(filepath):
    """Calcule et retourne l'empreinte SHA-256 du fichier donné."""
    sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()

# ── 2. Enregistrement de la référence ─────────────────────────────────────
def register_model_hash(filepath=MODEL_PATH, ref_path=HASH_REF_PATH):
    """
    Calcule le hash du modèle légitime et le sauvegarde comme référence.
    À appeler une seule fois après chaque mise à jour officielle du modèle.
    """
    h = compute_hash(filepath)
    os.makedirs(os.path.dirname(ref_path), exist_ok=True)
    with open(ref_path, "w") as f:
        json.dump({"model": filepath, "sha256": h}, f, indent=2)
    print(f"✅ Hash de référence enregistré : {h[:24]}...")
    return h

# ── 3. Vérification de l'intégrité ────────────────────────────────────────
def verify_model_integrity(filepath=MODEL_PATH, ref_path=HASH_REF_PATH):
    """
    Compare le hash actuel du modèle avec la référence enregistrée.
    Retourne (True, hash) si intact, (False, hash) si compromis.
    """
    if not os.path.exists(ref_path):
        print("⚠️  Aucun fichier de référence. Exécutez register_model_hash() d'abord.")
        return False, None

    with open(ref_path, "r") as f:
        ref = json.load(f)

    current_hash    = compute_hash(filepath)
    reference_hash  = ref.get("sha256", "")

    if current_hash == reference_hash:
        print(f"✅ Intégrité vérifiée ({current_hash[:16]}...)")
        return True, current_hash
    else:
        print(f"☠️  ALERTE INTÉGRITÉ : modèle modifié !")
        print(f"   Référence : {reference_hash[:16]}...")
        print(f"   Actuel    : {current_hash[:16]}...")
        return False, current_hash

# ── Point d'entrée direct ──────────────────────────────────────────────────
if __name__ == "__main__":
    print("Enregistrement du hash de référence du modèle ARIA...")
    register_model_hash()
