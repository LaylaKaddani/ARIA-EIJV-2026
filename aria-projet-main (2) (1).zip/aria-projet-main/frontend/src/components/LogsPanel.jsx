export default function LogsPanel({ logs }) {
  if (logs.length === 0) {
    return <p className="logs-empty">Aucune décision enregistrée.</p>;
  }

  return (
    <ul style={{listStyle: "none"}}>
      {logs.map((log, i) => {
        const cls = log.compromised
          ? "log-entry log-compromised"
          : log.label.includes("RISQUE")
            ? "log-entry log-risk"
            : "log-entry log-safe";

        return (
          <li key={i} className={cls}>
            <span style={{opacity: 0.5}}>[{log.time}]</span>{" "}
            {log.compromised
              ? "⛔ BLOQUÉ — modèle compromis"
              : `${log.label} — ${log.confidence}%`}
          </li>
        );
      })}
    </ul>
  );
}
