export default function StatusBar({ compromised }) {
  return (
    <div className={`status-bar ${compromised ? "status-danger" : "status-safe"}`}>
      <div className="status-dot" />
      <span>
        {compromised
          ? "⚠️  SYSTÈME COMPROMIS — INTÉGRITÉ DU MODÈLE VIOLÉE — PRÉDICTIONS BLOQUÉES"
          : "✅  SYSTÈME SÉCURISÉ — INTÉGRITÉ SHA-256 VÉRIFIÉE — ARIA OPÉRATIONNELLE"}
      </span>
      <div className="status-dot" />
    </div>
  );
}
