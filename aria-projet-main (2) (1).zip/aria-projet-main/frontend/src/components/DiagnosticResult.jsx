export default function DiagnosticResult({ result }) {
  if (!result) {
    return (
      <div className="diagnostic-waiting">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(0,180,255,0.3)" strokeWidth="1.5" style={{marginBottom: 12}}>
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
        </svg>
        <p>En attente de paramètres patient...</p>
      </div>
    );
  }

  // Cas : modèle compromis détecté par la défense backend
  if (result.compromised) {
    return (
      <div className="card diagnostic-compromised" style={{borderLeft: "4px solid #ff6b00"}}>
        <div className="diag-label compromised">⛔ PRÉDICTION BLOQUÉE</div>
        <div className="diag-alert">
          <strong>Défense SHA-256 activée</strong><br/>
          Le modèle a été modifié depuis son enregistrement.<br/>
          L'empreinte cryptographique ne correspond plus à la référence.<br/>
          Aucun diagnostic ne sera émis tant que le modèle n'est pas restauré.
        </div>
      </div>
    );
  }

  const isRisk = result.diagnostic === 1;

  return (
    <div className={`card ${isRisk ? "diagnostic-risk" : "diagnostic-safe"}`}>
      <div className={`diag-label ${isRisk ? "risk" : "safe"}`}>
        {isRisk ? "⚠️  RISQUE CARDIAQUE DÉTECTÉ" : "✅  AUCUN RISQUE DÉTECTÉ"}
      </div>
      <div className="diag-confidence">
        Confiance : <strong>{result.confidence}%</strong>
      </div>
      <div style={{fontFamily: "var(--mono)", fontSize: "0.68rem", color: "var(--text-dim)", marginTop: 8}}>
        Intégrité modèle : <span style={{color: "var(--accent2)"}}>✓ vérifiée</span>
      </div>
    </div>
  );
}
