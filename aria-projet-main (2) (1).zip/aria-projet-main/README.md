# Projet ARIA — Medical AI + Cybersécurité
**École d'Ingénieurs Jules Verne — 2025/2026**  
Assya · Marwa · Fatima Zahra · Layla

---

## Architecture du projet

```
aria-projet-main/
├── backend/
│   ├── app.py              ← Serveur Flask (avec vérification d'intégrité)
│   ├── defense.py          ← Système de défense SHA-256 (Layla)
│   ├── train_model.py      ← Entraîne le modèle légitime + enregistre le hash
│   ├── train_poisoned.py   ← Entraîne le modèle malveillant
│   ├── requirements.txt
│   ├── heart.csv           ← Dataset Heart Disease UCI (à placer ici)
│   └── models/             ← Créé automatiquement
│       ├── aria_model.pkl
│       ├── aria_model.sha256  ← Hash de référence (défense)
│       └── aria_poisoned.pkl
├── frontend/
│   ├── public/index.html
│   ├── src/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── index.js
│   │   └── components/
│   │       ├── PatientForm.jsx
│   │       ├── DiagnosticResult.jsx
│   │       ├── StatusBar.jsx
│   │       └── LogsPanel.jsx
│   └── package.json
└── attack/
    └── model_swap.py       ← Script d'attaque (démo)
```

---

## Installation et lancement

### Prérequis
- Python 3.9+
- Node.js 18+
- Le fichier `heart.csv` placé dans `backend/`

> Télécharger heart.csv : https://www.kaggle.com/datasets/johnsmith88/heart-disease-dataset

---

### 1. Backend

```bash
cd backend
pip install -r requirements.txt

# Entraîner le modèle légitime (génère aussi le hash de référence)
python train_model.py

# Entraîner le modèle empoisonné (pour la démo attaque)
python train_poisoned.py

# Lancer le serveur Flask
python app.py
```

Le backend tourne sur `http://localhost:5000`

---

### 2. Frontend

```bash
cd frontend
npm install
npm start
```

L'interface s'ouvre sur `http://localhost:3000`

---

## Démonstration de l'attaque + défense

### Étape 1 — État normal
Lancer un diagnostic → résultat normal, barre verte, intégrité vérifiée.

### Étape 2 — Lancer l'attaque (dans un terminal séparé)
```bash
cd attack
python model_swap.py
```
Le modèle est remplacé en quelques secondes.

### Étape 3 — Tenter un nouveau diagnostic
→ Le backend détecte la modification via SHA-256  
→ Retourne HTTP 403  
→ La barre passe au rouge : **SYSTÈME COMPROMIS**  
→ Aucun diagnostic n'est émis  

### Étape 4 — Restauration
Le script `model_swap.py` restaure automatiquement le modèle après 10 secondes.  
Relancer un diagnostic → la barre repasse au vert.

---

## Comment fonctionne la défense (defense.py)

1. `train_model.py` génère `aria_model.sha256` contenant l'empreinte SHA-256 du modèle légitime.
2. À chaque appel `/predict`, `app.py` appelle `verify_model_integrity()`.
3. Si l'empreinte actuelle du fichier `.pkl` diffère de la référence → HTTP 403, prédiction bloquée.
4. Le frontend affiche l'alerte rouge et log l'événement.
